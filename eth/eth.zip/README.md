# Shuttle Ethereum

# How to use
  * Update src/config
  * Update .env

```
$ cp ./.env_example ./.env
# Setup configuration on .env
$ nano ./.env
$ npm start
```

## Fixed
`monitoring.ts:165, 192`